import { PopularProducts } from "../data";
import React, { useEffect } from 'react';
import { createContext, useState } from 'react';
import { getProducts } from "../service/api.js";

const ProductContext = createContext();

export default ProductContext;

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await getProducts();
        setProducts(response.data);
      } catch (error) {
        console.log(error);
        // Fallback to PopularProducts in case of error
        setProducts(PopularProducts);
      }
    };
    fetchProducts();
  }, []);

  const value = { products };
  return (
    <ProductContext.Provider value={value}>
      {children}
    </ProductContext.Provider>
  );
};
